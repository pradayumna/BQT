@Author: Luise Higson and Pradyumna Agrawal
@Last_Update_Date: 2nd November, 2021

## How to Run ##
Please knitt the replication_study.rmd file using RStudio. Make sure that your system has latest version of tinyTex

## Dependencies
references.bib - For inlcuding references 
input_images - for including images 
tinyTex - for knitting
